# Čistá implementácia MD5-Crypt podľa python-md5crypt
import hashlib
import struct

def to64(value, length):
    chars = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    result = ""
    while length > 0:
        result += chars[value & 0x3f]
        value >>= 6
        length -= 1
    return result

def md5_crypt(password, salt, magic="$1$"):
    m = hashlib.md5()
    m.update(password.encode('utf-8') + magic.encode('utf-8') + salt.encode('utf-8'))

    # Alternate sum
    alt = hashlib.md5()
    alt.update(password.encode('utf-8') + salt.encode('utf-8') + password.encode('utf-8'))
    alt_result = alt.digest()

    for i in range(len(password)):
        m.update(alt_result[i % 16:i % 16+1])

    i = len(password)
    while i:
        if i & 1:
            m.update(b'\x00')
        else:
            m.update(password.encode('utf-8')[0:1])
        i >>= 1

    final = m.digest()

    # 1000 loops
    for i in range(1000):
        md5 = hashlib.md5()
        if i & 1:
            md5.update(password.encode('utf-8'))
        else:
            md5.update(final)
        if i % 3:
            md5.update(salt.encode('utf-8'))
        if i % 7:
            md5.update(password.encode('utf-8'))
        if i & 1:
            md5.update(final)
        else:
            md5.update(password.encode('utf-8'))
        final = md5.digest()

    # Arrange the output
    passwd = ''
    passwd += to64((struct.unpack('<I', final[0:4])[0]), 4)
    passwd += to64((struct.unpack('<I', final[4:8])[0]), 4)
    passwd += to64((struct.unpack('<I', final[8:12])[0]), 4)
    passwd += to64((struct.unpack('<I', final[12:16])[0]), 4)
    passwd = passwd[:22]  # md5_crypt password digest is 22 chars (excluding magic, salt, and $)
    return f"{magic}{salt}${passwd}"